public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, aerolinea of pat_mic......!");
        System.out.println("Hi, DS");
    }
}
