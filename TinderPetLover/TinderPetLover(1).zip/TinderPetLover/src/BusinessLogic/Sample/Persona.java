package BusinessLogic.Sample;

import java.util.ArrayList;
import java.util.List;

public class Persona {
    private String nombre;
    public List<Perro>  mascota = new ArrayList<Perro>();
    
}
