package BusinessLogic.Sample;

public class Perro {
    private String nombre;
    public Persona Propietario;
}
