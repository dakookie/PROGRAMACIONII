package BusinessLogic;

public class DataBase {
    // public boolean ConnDB(String strConnDB) throws Exception{
    //     DataAccessComponent dac = new DataAccessComponent();
    //     return dac.connDB(strConnDB);
    // }
}
