package BusinessLogic;

public class Invertebrado extends Animal{
    
}
