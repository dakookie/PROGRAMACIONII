package BusinessLogic;

public class Animal implements ICicloVida  {
    public String nombre;

    @Override
    public void Nacer(String Nombre) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void Crecer() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void Morir() {
        // TODO Auto-generated method stub
        
    }

    
}
