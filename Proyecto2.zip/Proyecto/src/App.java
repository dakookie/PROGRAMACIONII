import UserInterface.FrameMaster;
import UserInterface.samples.FrameLayout;

public class App {
    public static void main(String[] args) throws Exception {
        
        // frame = new FrameLayout("Pet-Lover");
        FrameMaster frm = new FrameMaster("Pet-Lover","Resourse\\img\\logo.png");
        // Cliente c = new Cliente();
        // c.Nacer("pepe");
        // c.Crecer();
        // c.reproducirseAmor();
        
        // JFrame frm  = new JFrame();                                  
        // frm.setTitle("Principal");                                   
        // frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);          
        // frm.setResizable(false);                                     
        // frm.setSize(500,500);                                        
        // frm.setVisible(true);        

        // ImageIcon image = new ImageIcon("Resourse\\img\\logo.png");                 
        // frm.setIconImage(image.getImage());                          
        // frm.getContentPane().setBackground(new  Color(12,111,54));   
    }
}
