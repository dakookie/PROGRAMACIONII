package BusinessLogic;

public interface ICicloVida {
    public void Nacer(String Nombre);
    public void Crecer();
    public void Morir();
}
