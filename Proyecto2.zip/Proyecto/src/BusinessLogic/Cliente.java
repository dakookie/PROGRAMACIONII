package BusinessLogic;

public class Cliente extends Persona implements ICicloFeliz {

    @Override
    public void reproducirse() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void reproducirseAmor() {
        // TODO Auto-generated method stub
        
    }
    
}
