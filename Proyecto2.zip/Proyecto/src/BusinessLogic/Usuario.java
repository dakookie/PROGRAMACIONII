package BusinessLogic;

public class Usuario extends Persona{
    
}
