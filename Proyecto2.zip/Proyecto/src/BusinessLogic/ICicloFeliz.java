package BusinessLogic;

public interface ICicloFeliz {
    public void reproducirse();
    public void reproducirseAmor();
}
