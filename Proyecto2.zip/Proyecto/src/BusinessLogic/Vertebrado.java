package BusinessLogic;

public class Vertebrado extends Animal{
    
}
